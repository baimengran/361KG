<?php

namespace app\admin\model;

use think\Model;

class Menu extends Model
{
    //
    protected $name = 'auth_rule';

    // 开启自动写入时间戳字段
    protected $autoWriteTimestamp = true;

}
