<?php

namespace app\admin\model;

use think\Model;

class Ad extends Model
{
    //
}
