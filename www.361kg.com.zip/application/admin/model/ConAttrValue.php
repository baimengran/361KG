<?php

namespace app\admin\model;

use think\Model;

class ConAttrValue extends Model
{
    //
}
