<?php

namespace app\api\model;

use think\Model;

class Issue extends Model
{
    //
}
