$.ajaxSetup({
    statusCode: {
        200: function (data) {
            if(data.code==999){
                layer.msg('登录超时',{icon:2,time:1500,shade:0.1},function(index){
                    location.href="/admin/login/index";
                });
            }
        }
    }
})
