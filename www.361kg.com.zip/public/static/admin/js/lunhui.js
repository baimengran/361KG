var lunhui = {

    //成功弹出层
    success: function (message, url) {
        layer.msg(message, {icon: 1, time: 2000}, function (index) {
            layer.close(index);
            window.location.href = url;
        });
    },

    // 错误弹出层
    error: function (message) {
        layer.msg(message, {icon: 2, time: 2000}, function (index) {
            layer.close(index);
        });
    },

    // 确认弹出层
    confirm: function (id, url) {
        layer.confirm('确认删除此条记录吗?', {icon: 3, title: '提示'}, function (index) {
            $.getJSON(url, {'id': id}, function (res) {
                if (res.code === 1) {
                    layer.msg(res.msg, {icon: 1, time: 1500, shade: 0.1});
                    // Ajaxpage();
                    // location.replace(location.href);
                    window.location.reload();
                } else {
                    layer.msg(res.msg, {icon: 2, time: 1500, shade: 0.1});
                }
            });
            layer.close(index);
        })
    },

    //状态
    status: function (id, url, sign1 = '禁用', sign2 = '开启') {
        $.post(url, {id: id}, function (data) {
            if (data.code === 1) {
                var a = '<span class="label label-info">' + data.msg + '</span>'
                $('#zt' + id).html(a);
                layer.msg(data.msg, {icon: 1, time: 1500, shade: 0.1,});
                // location.replace(location.href);
                window.location.reload();
                return false;
            } else if(data.code===0){
                var b = '<span class="label label-danger">' + data.msg + '</span>'
                $('#zt' + id).html(b);
                layer.msg(data.msg, {icon: 2, time: 1500, shade: 0.1,});
                // location.replace(location.href);
                window.location.reload();
                return false;
            }else{
                layer.msg(data.msg, {icon: 2, time: 3000, shade: 0.1,});
                return false;
            }
        });
        return false;
    },

    //状态
    marquee_status: function (id, url, sign1 = '禁用', sign2 = '开启') {
        $.post(url, {id: id}, function (data) {
            if (data.code === 1) {
                var a = '<span class="label label-danger">' + data.msg + '</span>'
                $('#zt' + id).html(a);
                layer.msg(data.msg, {icon: 2, time: 1500, shade: 0.1,});
                // location.replace(location.href);
                window.location.reload();
                return false;
            } else {
                var b = '<span class="label label-info">' + data.msg + '</span>'
                $('#zt' + id).html(b);
                layer.msg(data.msg, {icon: 1, time: 1500, shade: 0.1,});
                // location.replace(location.href);
                window.location.reload();
                return false;
            }
        });
        return false;
    },
    marquee_cate_status: function (id, cate, url, sign1 = '禁用', sign2 = '开启') {
        $.post(url, {id: id, cate: cate}, function (data) {
            if (data.code === 11) {
                var a = '<span class="label label-info">' + data.msg + '</span>'
                $('#zd' + id).html(a);
                layer.msg(data.msg, {icon: 1, time: 1500, shade: 0.1,});
                // location.replace(location.href);
                window.location.reload();
                return false;
            } else if (data.code == 10) {
                var b = '<span class="label label-info">' + data.msg + '</span>'
                $('#zd' + id).html(b);
                layer.msg(data.msg, {icon: 1, time: 1500, shade: 0.1,});
                // location.replace(location.href);
                window.location.reload();
                return false;
            }
        });
        return false;
    },

    //叫车状态
    taxi_status: function (id, status, cate, url, sign1 = '禁用', sign2 = '开启') {
        $.post(url, {id: id, status: status, cate: cate}, function (data) {
            if (data.code === 1) {
                var a = '<span class="label label-info">' + data.msg + '</span>'
                $('#zt' + id).html(a);
                layer.msg(data.msg, {icon: 2, time: 1500, shade: 0.1,});
                location.replace(location.href);
                // window.location.reload();
                return false;
            } else if (data.code === 2) {
                var a = '<span class="label label-default">' + data.msg + '</span>'
                $('#zt' + id).html(a);
                layer.msg(data.msg, {icon: 2, time: 1500, shade: 0.1,});
                location.replace(location.href);
                // window.location.reload();
                return false;
            }
            else if (data.code == 0) {
                var c = '<span class="label label-danger">' + data.msg + '</span>'
                $('#zt' + id).html(c);
                layer.msg(data.msg, {icon: 1, time: data['sleep'], shade: 0.1,});
                location.replace(location.href);
                // window.location.reload();
                return false;
            }
            else {
                layer.msg(data.msg, {icon: 2, time: data['sleep'], shade: 0.1,});
                // location.replace(location.href);
                // window.location.reload();
                return false;
            }
        });
        return false;
    },
    //首页美食状态
    home_status: function (id, url, sign1 = '禁用', sign2 = '开启') {
        $.post(url, {id: id}, function (data) {
            if (data.code === 1) {
                var a = '<span class="label label-danger">' + data.msg + '</span>'
                $('#zd' + id).html(a);
                layer.msg(data.msg, {icon: 2, time: 1500, shade: 0.1,});
                location.replace(location.href);
                // window.location.reload();
                return false;
            } else if (data.code === 3) {
                var a = '<span class="label label-danger">' + data.msg + '</span>'
                $('#zd' + id).html(a);
                layer.msg(data.msg, {icon: 2, time: 1500, shade: 0.1,});
                // location.replace(location.href);
                // window.location.reload();
                return false;
            }
            else {
                var c = '<span class="label label-info">' + data.msg + '</span>'
                $('#zd' + id).html(c);
                layer.msg(data.msg, {icon: 1, time: 1500, shade: 0.1,});
                location.replace(location.href);
                // window.location.reload();
                return false;
            }
        });
        return false;
    },
}